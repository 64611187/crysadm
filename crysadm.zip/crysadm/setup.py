__author__ = 'powergx'
from distutils.core import setup

setup(
    name='crysadm',
    version='',
    packages=[],
    url='',
    license='',
    author='',
    author_email='',
    description='',
    requires=['redis', 'requests', 'flask']
)
